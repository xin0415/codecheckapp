package sc.workspace;

import djf.ui.AppMessageDialogSingleton;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import javafx.scene.image.Image;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import properties_manager.PropertiesManager;
import sc.SlideshowCreatorApp;
import static sc.SlideshowCreatorProp.APP_PATH_WORK;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_MESSAGE;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_TITLE;
import sc.data.Slide;
import sc.data.SlideshowCreatorData;

/**
 * This class provides responses to all workspace interactions, meaning
 * interactions with the application controls not including the file
 * toolbar.
 * 
 * @author Richard McKenna
 * @author Jason Dong
 * @version 1.0
 */
public class SlideshowCreatorController {
    // THE APP PROVIDES ACCESS TO OTHER COMPONENTS AS NEEDED
    SlideshowCreatorApp app;

    /**
     * Constructor, note that the app must already be constructed.
     */
    public SlideshowCreatorController(SlideshowCreatorApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;
    }
    
    // CONTROLLER METHOD THAT HANDLES ADDING A DIRECTORY OF IMAGES
    public void handleAddAllImagesInDirectory() {
        try {
            // ASK THE USER TO SELECT A DIRECTORY
            DirectoryChooser dirChooser = new DirectoryChooser();
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            dirChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));
            File dir = dirChooser.showDialog(app.getGUI().getWindow());
            SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
            if (dir != null) {
                File[] files = dir.listFiles();
                for (File f : files) {
                    String fileName = f.getName();
                    if (fileName.toLowerCase().endsWith(".png") ||
                            fileName.toLowerCase().endsWith(".jpg") ||
                            fileName.toLowerCase().endsWith(".gif")) {
                        String path = f.getPath();
                        String caption = "";
                        Image slideShowImage = loadImage(path);
                        int originalWidth = (int)slideShowImage.getWidth();
                        int originalHeight = (int)slideShowImage.getHeight();
                        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
                        Slide slideToAdd = new Slide(fileName,path,caption,originalWidth,originalHeight);
                        if (!data.contains(slideToAdd)) {
                            data.addSlide(slideToAdd);
                        }
                    }
                }
                workspace.slidesTableView.requestFocus();
                workspace.slidesTableView.getSelectionModel().clearSelection();
            }
        }
        catch(MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }
    
    public void handleAddImage() {
        try {
            FileChooser fileChooser = new FileChooser();
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            fileChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));
            File file = fileChooser.showOpenDialog(app.getGUI().getWindow());
            if (file != null) {
                String fileName = file.getName();
                if (fileName.toLowerCase().endsWith(".png") ||
                        fileName.toLowerCase().endsWith(".jpg") ||
                        fileName.toLowerCase().endsWith(".gif")) {
                    String path = file.getPath();
                    String caption = "";
                    Image slideShowImage = loadImage(path);
                    int originalWidth = (int)slideShowImage.getWidth();
                    int originalHeight = (int)slideShowImage.getHeight();
                    SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
                    Slide slideToAdd = new Slide(fileName,path,caption,originalWidth,originalHeight);
                    if (!data.contains(slideToAdd)) {
                        data.addSlide(slideToAdd);
                        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
                        workspace.slidesTableView.requestFocus();
                        workspace.slidesTableView.getSelectionModel().selectLast();
                        handleSlideSelection();
                    }
                }
            }
        }
        catch(MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }
    
    public void handleRemoveImage() {
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        Slide slideToBeRemoved = workspace.slidesTableView.getSelectionModel().getSelectedItem();
        int index = workspace.slidesTableView.getItems().indexOf(slideToBeRemoved);
        workspace.slidesTableView.getItems().remove(index);
    }
    
    public void handleUpdate() {
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        Slide slideToBeUpdated = workspace.slidesTableView.getSelectionModel().getSelectedItem();
        slideToBeUpdated.setCaption(workspace.captionTextField.getText());
        slideToBeUpdated.setCurrentWidth(Math.round((float)workspace.currentWidthSlider.getValue()));
        slideToBeUpdated.setCurrentHeight(Math.round((float)workspace.currentHeightSlider.getValue()));
        int index = workspace.slidesTableView.getItems().indexOf(slideToBeUpdated);
        workspace.slidesTableView.getItems().set(index, slideToBeUpdated);
    }
    
    public void handleSlideSelection() {
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        if (workspace.slidesTableView.getSelectionModel().getSelectedItem() != null) {
            Slide selected = workspace.slidesTableView.getSelectionModel().getSelectedItem();
            workspace.fileNameTextField.setText(selected.getFileName());
            workspace.pathTextField.setText(selected.getPath());
            workspace.captionTextField.setText(selected.getCaption());
            workspace.originalWidthTextField.setText(Integer.toString(selected.getOriginalWidth()));
            workspace.originalHeightTextField.setText(Integer.toString(selected.getOriginalHeight()));
            workspace.currentWidthSlider.setValue(selected.getCurrentWidth());
            workspace.currentHeightSlider.setValue(selected.getCurrentHeight());
        }
    }
    
    public void handleCurrentWidthSlider() {
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        workspace.currentWidthPromptLabel.setText("Current Width: " + Math.round((float)workspace.currentWidthSlider.getValue()));
    }
    
    public void handleCurrentHeightSlider() {
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        workspace.currentHeightPromptLabel.setText("Current Height: " + Math.round((float)workspace.currentHeightSlider.getValue()));
    }
    
    // THIS HELPER METHOD LOADS AN IMAGE SO WE CAN SEE IT'S SIZE
    private Image loadImage(String imagePath) throws MalformedURLException {
	File file = new File(imagePath);
	URL fileURL = file.toURI().toURL();
	Image image = new Image(fileURL.toExternalForm());
	return image;
    }
}