package sc.workspace;

import djf.ui.AppMessageDialogSingleton;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import javafx.animation.KeyFrame;
import javafx.util.Duration;
import javafx.animation.Timeline;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import jtps.AddSlide_Transaction;
import jtps.Updata_Transaction;
import properties_manager.PropertiesManager;
import sc.SlideshowCreatorApp;
import static sc.SlideshowCreatorProp.APP_PATH_WORK;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_MESSAGE;
import static sc.SlideshowCreatorProp.INVALID_IMAGE_PATH_TITLE;
import sc.data.Slide;
import sc.data.SlideshowCreatorData;
import jtps.jTPS;
import jtps.jTPS_Transaction;
import static sc.SlideshowCreatorProp.NEXT_BUTTON_TEXT;
import static sc.SlideshowCreatorProp.PREVIOUS_BUTTON_TEXT;
import static sc.SlideshowCreatorProp.PLAY_BUTTON_TEXT;
import static sc.SlideshowCreatorProp.PAUSE_BUTTON_TEXT;
import static sc.style.SlideshowCreatorStyle.CLASS_EDIT_BUTTON;


/**
 * This class provides responses to all workspace interactions, meaning
 * interactions with the application controls not including the file
 * toolbar.
 * 
 * @author Richard McKenna
 * @version 1.0
 */
public class SlideshowCreatorController {
    // THE APP PROVIDES ACCESS TO OTHER COMPONENTS AS NEEDED
    SlideshowCreatorApp app;
    Button nextButton;
    Button previousButton;
    Button playButton;
    Button pauseButton;
    ImageView ivew;
    int position;
    FlowPane buttonToolbar;
    VBox root;
    Timeline timeline;
    Label capI;
    public static jTPS jtps;
    GraphicsContext      gc;
    /**
     * Constructor, note that the app must already be constructed.
     */
    public SlideshowCreatorController(SlideshowCreatorApp initApp) {
        // KEEP THIS FOR LATER
        app = initApp;
        jtps=new jTPS();
    }
    
    // CONTROLLER METHOD THAT HANDLES ADDING A DIRECTORY OF IMAGES
    public void handleAddAllImagesInDirectory() {
        try {
            // ASK THE USER TO SELECT A DIRECTORY
            DirectoryChooser dirChooser = new DirectoryChooser();
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            dirChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));
            File dir = dirChooser.showDialog(app.getGUI().getWindow());
            if (dir != null) {
                File[] files = dir.listFiles();
                for (File f : files) {
                    String fileName = f.getName();
                    if (fileName.toLowerCase().endsWith(".png") ||
                            fileName.toLowerCase().endsWith(".jpg") ||
                            fileName.toLowerCase().endsWith(".gif")) {
                        String path = f.getPath();
                        String caption = "";
                        Image slideShowImage = loadImage(path);
                        int originalWidth = (int)slideShowImage.getWidth();
                        int originalHeight = (int)slideShowImage.getHeight();
                        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
                        data.addNonDuplicateSlide(fileName, path, caption, originalWidth, originalHeight);
                    }
                }
            }
        }
        catch(MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }
    
    public void handleAddImage() {
        try {
            // ASK THE USER TO SELECT A DIRECTORY
            FileChooser imageChooser = new FileChooser();
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            imageChooser.setInitialDirectory(new File(props.getProperty(APP_PATH_WORK)));
            File imageFile = imageChooser.showOpenDialog(app.getGUI().getWindow());
            if (imageFile != null) {
                String fileName = imageFile.getName();
                if (fileName.toLowerCase().endsWith(".png") ||
                            fileName.toLowerCase().endsWith(".jpg") ||
                            fileName.toLowerCase().endsWith(".gif")) {
                    String path = imageFile.getPath();
                    String caption = "";
                    Image slideShowImage = loadImage(path);
                    int originalWidth = (int)slideShowImage.getWidth();
                    int originalHeight = (int)slideShowImage.getHeight();
                    SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
                    data.addNonDuplicateSlide(fileName, path, caption, originalWidth, originalHeight);
                    
                }
            }
            
        }
        catch(MalformedURLException murle) {
            PropertiesManager props = PropertiesManager.getPropertiesManager();
            String title = props.getProperty(INVALID_IMAGE_PATH_TITLE);
            String message = props.getProperty(INVALID_IMAGE_PATH_MESSAGE);
            AppMessageDialogSingleton dialog = AppMessageDialogSingleton.getSingleton();
            dialog.show(title, message);
        }
    }
    public void handleSlideUp(){
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        TableView slidesTableView = workspace.slidesTableView;
        Slide selectedSlide = (Slide)slidesTableView.getSelectionModel().getSelectedItem();
        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
        data.moveSlideup(selectedSlide);
        slidesTableView.getSelectionModel().clearSelection();
        workspace.enableSlideEditingControls(false);
    }
    
    public void handleSlideDown(){
        
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        TableView slidesTableView = workspace.slidesTableView;
        Slide selectedSlide = (Slide)slidesTableView.getSelectionModel().getSelectedItem();
        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
        data.moveSlidedown(selectedSlide);
        
        slidesTableView.getSelectionModel().clearSelection();
        workspace.enableSlideEditingControls(false);
    }
    
    public void handleRemoveImage() {
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        TableView slidesTableView = workspace.slidesTableView;
        Slide selectedSlide = (Slide)slidesTableView.getSelectionModel().getSelectedItem();
        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
        data.removeSlide(selectedSlide);
        if(data.app.getGUI().fileController.saveAs!=null)
         data.app.getGUI().saveAsButton.setDisable(false);
        else
            data.app.getGUI().saveButton.setDisable(false);
        //slidesTableView.getSelectionModel().clearSelection();
        //workspace.enableSlideEditingControls(false);
    }
    
    public void handleUpdateSlide() {
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        workspace.updateButton.setDisable(true);
        
        TableView slidesTableView = workspace.slidesTableView;
        Slide selectedSlide = (Slide)slidesTableView.getSelectionModel().getSelectedItem();
        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
        System.out.println(data.app.getGUI().fileController.saveAs);
        if(data.app.getGUI().fileController.saveAs!=null)
         data.app.getGUI().saveAsButton.setDisable(false);
        else
            data.app.getGUI().saveButton.setDisable(false);
        String caption = workspace.captionTextField.getText();
        int currentWidth = (int)workspace.currentWidthSlider.getValue();
        int currentHeight = (int)workspace.currentHeightSlider.getValue();
        int currentX = (int)workspace.xposition.getValue();
        int currentY = (int)workspace.yposition.getValue();
        
        jTPS_Transaction up=new Updata_Transaction(app,selectedSlide,currentWidth,currentHeight,currentX,currentY,caption);
        jtps.addTransaction(up);
        
        workspace.updateButton.setDisable(true);
        
        //selectedSlide.setCaption(caption);
        //selectedSlide.setCurrentWidth(currentWidth);
        //selectedSlide.setCurrentHeight(currentHeight);
        //selectedSlide.setX(currentX);
        //selectedSlide.setY(currentY);
        //workspace.slidesTableView.refresh();
    }
    
    public void handleSelectSlide() {
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        Slide selectedSlide = workspace.slidesTableView.getSelectionModel().getSelectedItem();
        int selectedIndex = workspace.slidesTableView.getSelectionModel().getSelectedIndex();
        
        // WE ONLY RESPOND IF IT'S A SELECTION
        if (selectedIndex >= 0) {
            // LOAD ALL THE SLIDE DATA INTO THE CONTROLS
            workspace.fileNameTextField.setText(selectedSlide.getFileName());
            workspace.pathTextField.setText(selectedSlide.getPath());
            workspace.captionTextField.setText(selectedSlide.getCaption());
            workspace.originalWidthTextField.setText("" + selectedSlide.getOriginalWidth());
            workspace.originalHeightTextField.setText("" + selectedSlide.getOriginalHeight());
            workspace.currentWidthSlider.setValue(selectedSlide.getCurrentWidth().doubleValue());
            workspace.currentHeightSlider.setValue(selectedSlide.getCurrentHeight().doubleValue());
            workspace.xposition.setValue(selectedSlide.getX().doubleValue());
            workspace.yposition.setValue(selectedSlide.getY().doubleValue());
            File f=new File(selectedSlide.getPath());
            workspace.iv.setImage(new Image(f.toURI().toString()));
            SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
            int h=handlePosition();
            System.out.println(h);
            System.out.println(data.slides.size()-1);
            if(h==0){
                workspace.slideUp.setDisable(true);
                workspace.slideDown.setDisable(false);
            }else if(h==(data.slides.size()-1)){
                workspace.slideUp.setDisable(false);
                workspace.slideDown.setDisable(true);
            }else{
                workspace.slideUp.setDisable(false);
                workspace.slideDown.setDisable(false);
            }
                
            
        
            workspace.enableSlideEditingControls(true);
        }
    }
    
    // THIS HELPER METHOD LOADS AN IMAGE SO WE CAN SEE IT'S SIZE
    private Image loadImage(String imagePath) throws MalformedURLException {
	File file = new File(imagePath);
	URL fileURL = file.toURI().toURL();
	Image image = new Image(fileURL.toExternalForm());
	return image;
    }
    
    public void handleViewSlide(){
        Stage stage=new Stage();
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        if (workspace.slideshow!=null)
            stage.setTitle(workspace.slideshow.getText());
        else
         stage.setTitle("Slide Show");
        root = new VBox();
	
	PropertiesManager props = PropertiesManager.getPropertiesManager();
        nextButton=new Button(props.getProperty(NEXT_BUTTON_TEXT));
        previousButton=new Button(props.getProperty(PREVIOUS_BUTTON_TEXT));
        playButton=new Button(props.getProperty(PLAY_BUTTON_TEXT));
        pauseButton=new Button(props.getProperty(PAUSE_BUTTON_TEXT));
        
        List<String> fontFamilies = javafx.scene.text.Font.getFamilies();
	String randomFontFamily = fontFamilies.get((int)(Math.random()*fontFamilies.size()));
	Font buttonFont = new Font(randomFontFamily, 36);
	previousButton.setFont(buttonFont);
	playButton.setFont(buttonFont);
	nextButton.setFont(buttonFont);
        pauseButton.setFont(buttonFont);
        pauseButton.setDisable(true);
        
        
        nextButton.setOnAction(e->{
            handleNextImage();
        });
        previousButton.setOnAction(e->{
            handlePreviousImage();
        });
        playButton.setOnAction(e->{
            handlePlay();
        });
        pauseButton.setOnAction(e->{
            handlePause();
        });
        
        
        buttonToolbar = new FlowPane();
        buttonToolbar.setAlignment(Pos.CENTER);
        buttonToolbar.getChildren().addAll(previousButton, nextButton,playButton, pauseButton);
        
        //SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        TableView slidesTableView = workspace.slidesTableView;
        Slide selectedSlide = (Slide)slidesTableView.getSelectionModel().getSelectedItem();
        ivew=new ImageView();
        File f=new File(selectedSlide.getPath());
        ivew.setImage(new Image(f.toURI().toString()));
        ivew.setFitHeight(selectedSlide.getCurrentHeight());
        ivew.setFitWidth(selectedSlide.getCurrentWidth());
        //System.out.println(selectedSlide.getX());
        ivew.setX(selectedSlide.getX());
        ivew.setY(selectedSlide.getY());
        position=handlePosition();
        //ivew.translateXProperty()
        //Canvas canvas = new Canvas(300, 250);
        //gc = canvas.getGraphicsContext2D();
        //gc.drawImage(new Image(f.toURI().toString()), selectedSlide.getX(), selectedSlide.getY());
        
        
        
        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
        if(position==0)
            previousButton.setDisable(true);
        else if(position==data.slides.size()-1)
            nextButton.setDisable(true);
        
        capI=new Label(selectedSlide.getCaption());
        capI.setFont(new Font(randomFontFamily, 48));
        
        root.setAlignment(Pos.CENTER);
        root.getChildren().add(buttonToolbar);
        //root.getChildren().add(canvas);
        root.getChildren().add(ivew);
        root.getChildren().add(capI);
        Scene scene = new Scene(root, 800, 800);
	stage.setScene(scene);
        //stage.add(ivew);
        stage.sizeToScene();
        stage.show();
    }
    
    public int handlePosition(){
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        TableView slidesTableView = workspace.slidesTableView;
        Slide selectedSlide = (Slide)slidesTableView.getSelectionModel().getSelectedItem();
        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
        
        
        int c=0;
        for(Slide o: data.slides){
            if(o.getFileName().equals(selectedSlide.getFileName())){
                break;
            }
            else
              c++;  
        }
        return c;
    }
    
    public void handlePause(){
        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
        nextButton.setDisable(false);
        previousButton.setDisable(false);
        if(position==(data.slides.size()-1))
         nextButton.setDisable(true);
        else if (position==0)
        previousButton.setDisable(true);
        playButton.setDisable(false);
        pauseButton.setDisable(true);
        timeline.stop();
    }
    
    public void handlePlay(){
        nextButton.setDisable(true);
        previousButton.setDisable(true);
        playButton.setDisable(true);
        pauseButton.setDisable(false);
        if (timeline != null)
                timeline.stop();
            //timeSeconds = STARTTIME;
            
            //timerLabel.setText(timeSeconds.toString());  // updating the timer label every second
            timeline = new Timeline();                   // setting up the timeline
            timeline.setCycleCount(Timeline.INDEFINITE); // animation continues until stop() is called
            
            // A timeline consists of KeyFrames
            // It uses these KeyFrame objects to represent the different time frames
            timeline.getKeyFrames().add(
                    new KeyFrame(Duration.seconds(2),       // each time frame lasts for one second
                                 keyframeEventHandler -> {  // at the end of each frame, this event handler is executed
                                    SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
                                    if(position==(data.slides.size()-1))
                                        position=-1;
                                    handleNextImage();
                                    previousButton.setDisable(true);
                                 }));
            timeline.playFromStart();
    }
    
    public void handleNextImage(){
        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
        previousButton.setDisable(false);
        int listSize=data.slides.size();
        if(position!=(listSize-1)){
            Slide selectedSlide=data.slides.get(++position);
            ivew=new ImageView();
            File f=new File(selectedSlide.getPath());
            ivew.setImage(new Image(f.toURI().toString()));
            ivew.setFitHeight(selectedSlide.getCurrentHeight());
            ivew.setFitWidth(selectedSlide.getCurrentWidth());
            ivew.setX(selectedSlide.getX());
            ivew.setY(selectedSlide.getY());
            
            capI.setText(selectedSlide.getCaption());
            root.getChildren().clear();
            root.getChildren().addAll(buttonToolbar,ivew,capI);
            if(position==(listSize-1))
                nextButton.setDisable(true);
        }
    }
    public void handlePreviousImage(){
        SlideshowCreatorData data = (SlideshowCreatorData)app.getDataComponent();
        nextButton.setDisable(false);
        if(position!=0){
            Slide selectedSlide=data.slides.get(--position);
            System.out.println(selectedSlide.getFileName());
            ivew=new ImageView();
            File f=new File(selectedSlide.getPath());
            ivew.setImage(new Image(f.toURI().toString()));
            ivew.setFitHeight(selectedSlide.getCurrentHeight());
            ivew.setFitWidth(selectedSlide.getCurrentWidth());
            ivew.setX(selectedSlide.getX());
            ivew.setY(selectedSlide.getY());
            capI.setText(selectedSlide.getCaption());
            root.getChildren().clear();
            root.getChildren().addAll(buttonToolbar,ivew,capI);
            if(position==0)
                previousButton.setDisable(true);
        }
    }
    
    
    void handleCaptionTextTyped() {
        SlideshowCreatorWorkspace gui = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        gui.updateButton.setDisable(false);
    }
    
    void handleSliderMoved() {
        SlideshowCreatorWorkspace gui = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        gui.updateButton.setDisable(false);        
    }
}