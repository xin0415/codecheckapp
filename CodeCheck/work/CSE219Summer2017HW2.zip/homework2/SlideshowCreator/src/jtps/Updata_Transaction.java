/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jtps;

import sc.SlideshowCreatorApp;
import sc.data.Slide;
import sc.data.SlideshowCreatorData;
import sc.workspace.SlideshowCreatorWorkspace;

/**
 *
 * @author xin
 */
public class Updata_Transaction implements jTPS_Transaction {
    SlideshowCreatorApp app;
    Slide s;
    int currentHeight;
    int currentWidth;
    int x;
    int y;
    String cap;
    int oldW;
    int oldH;
    int oldx;
    int oldy;
    String oldc;
    
    public Updata_Transaction(SlideshowCreatorApp app, Slide s, int currentWidth, int currentHeight, int x, int y, String cap){
        this.app=app;
        this.s=s;
        this.currentWidth=currentWidth;
        this.currentHeight=currentHeight;
        this.x=x;
        this.y=y;
        this.cap=cap;
    }

    public Updata_Transaction(SlideshowCreatorApp app, String caption, int currentWidth, int currentHeight, int currentX, int currentY) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    @Override
    public void doTransaction(){
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        oldW=s.getCurrentWidth();
        oldH=s.getCurrentHeight();
        oldx=s.getX();
        oldy=s.getY();
        oldc=s.getCaption();
        s.setCurrentWidth(currentWidth);
        s.setCurrentHeight(currentHeight);
        s.setX(x);
        s.setY(y);
        s.setCaption(cap);
        workspace.currentWidthSlider.setValue(currentWidth);
        workspace.currentHeightSlider.setValue(currentHeight);
        workspace.xposition.setValue(x);
        workspace.yposition.setValue(y);
        workspace.captionTextField.setText(cap);
        //workspace.updateButton.setDisable(true);
        workspace.slidesTableView.refresh();
    }
    
    @Override
    public void undoTransaction(){
        SlideshowCreatorWorkspace workspace = (SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        s.setCurrentWidth(oldW);
        s.setCurrentHeight(oldH);
        s.setX(oldx);
        s.setY(oldy);
        s.setCaption(oldc);
        workspace.currentWidthSlider.setValue(oldW);
        workspace.currentHeightSlider.setValue(oldH);
        workspace.xposition.setValue(oldx);
        workspace.yposition.setValue(oldy);
        workspace.captionTextField.setText(oldc);
        //workspace.updateButton.setDisable(true);
        workspace.slidesTableView.refresh();
    }
}
