/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jtps;
import sc.SlideshowCreatorApp;
import sc.data.SlideshowCreatorData;
import sc.workspace.SlideshowCreatorWorkspace;
/**
 *
 * @author xin
 */
public class AddSlide_Transaction implements jTPS_Transaction {
    SlideshowCreatorApp app;
    String fileName;
    String path;
    int originalWidth;
    int originalHeight;
    int currentHeight;
    int currentWidth;
    int x;
    int y;
    String cap;
    public AddSlide_Transaction(SlideshowCreatorApp app, String fileName, String path,String cap, int originalWidth, int originalHeight, int currentWidth, int currentHeight, int x, int y ){
        this.app=app;
        this.fileName=fileName;
        this.path=path;
        this.originalWidth=originalWidth;
        this.originalHeight=originalHeight;
        this.currentHeight=currentHeight;
        this.currentWidth=currentWidth;
        this.x=x;
        this.y=y;
        this.cap=cap;
    }
    @Override
    public void doTransaction(){
        SlideshowCreatorWorkspace workspace=(SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        SlideshowCreatorData data=(SlideshowCreatorData)app.getDataComponent();
        data.addSlide(fileName, path, cap, originalWidth, originalHeight, currentWidth, currentHeight, x, y);
    }
    
    @Override
    public void undoTransaction(){
        SlideshowCreatorWorkspace workspace=(SlideshowCreatorWorkspace)app.getWorkspaceComponent();
        SlideshowCreatorData data=(SlideshowCreatorData)app.getDataComponent();
        data.removes(fileName);
    }
}
